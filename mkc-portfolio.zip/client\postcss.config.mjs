const config = {
  plugins: {},
};

export default config;
